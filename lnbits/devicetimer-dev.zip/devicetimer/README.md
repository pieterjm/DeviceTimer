# DeviceTimer

This is an LNbits extension for the creation of LNURL device that are only accessible with a defined time window. Outside of the time window, payments are not accepted.



